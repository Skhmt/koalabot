/*
	Copyright (C) 2016  skhmt

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation version 3.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

 // vars
var clientid = '3y2ofy4qcsvnaybw9ogdzwmwfode8y0'; /* this is the (public) client_id of KoalaBot. */
var fs;
var logFile;
var execPath;
var hosts = [];
var viewers = [];
var startDate = new Date();
var subBadgeUrl = '';
var permitted = [];
var emoticons = [];
var currentUsers = [];
var recentEvents = [];
var mainwin;
var gui;
var sql;
var oauthsetup = false;

var rawIrcOn = false;
var commandsOn = true;

var settings = {
	access_token: "",
	username: "",
	channel: "",
	id: "",
	theme: "default"
};

$(document).ready( function() {

	fs = require( 'fs' );
	sql = require( 'sql.js' );

	// Setting up the save on close feature
	mainwin = nw.Window.get();
	mainwin.on( 'close', function() {
		this.hide();
		console.log('Final save');
		save();
		setTimeout(function(){
			this.close(true);
		}, 500);
	} );

	// Setting up OS X specific behavior
    if ( process.platform == 'win32' ) {
		var path = require( 'path' );
        execPath = `${path.dirname( process.execPath )}/`;
    }
    else if ( process.platform == 'darwin' ) {
        execPath = '';
        var nativeMenuBar = new nw.Menu( { type: 'menubar' } );
        nativeMenuBar.createMacBuiltin( 'KoalaBot' );
        mainwin.menu = nativeMenuBar;
    }
    else { // linux flavor?
        execPath = '';
    }

	// Checking if default.css exists in /themes/
	try { fs.accessSync( `${execPath}themes/default.css` ); }
	catch (e) { // if it doesn't exist, basically copy+paste it
		var defaultcss = fs.readFileSync('default.css', 'utf8');
		fs.writeFileSync(`${execPath}themes/default.css`, defaultcss, 'utf8');
	}
	$('#botTheme').attr( 'href', `${execPath}themes/default.css` );

	$('#botThemeCurrent').html( 'default' );
	settings.theme = 'default';

	// UI things

	setTitle('');

	$('#changeChannel').click( function() {
		var newchan = $('#getChannelField').val().toLowerCase();
		if ( newchan.substring(0,1) !== '#' ) { // if the user forgot the #, add it
			newchan = '#' + newchan;
			$('#getChannelField').val( newchan );
		}

		if ( newchan !== settings.channel ) { // if the channel is actually different
			settings.channel = newchan;
			channelEnter();
		}
	} );

	$('#getOauthLink').click( setupOauth );

	//	populate the #botThemeList
	fs.readdir(`${execPath}themes`, function(err, files){
		for ( var f = 0; f < files.length; f++ ) {
			var splitName = files[f].split('.');
			if ( splitName[1] == 'css' ) {
				$('#botThemeList').append(`
					<option value="${files[f]}">
						${splitName[0]}
					</option>`);
			}
		}
	} );

	$('#botThemeChange').click(function() {
		var tempTheme = $('#botThemeList').val();
		$('#botTheme').attr( 'href', `${execPath}themes/${tempTheme}` );
		$('#botThemeCurrent').html(tempTheme.split('.')[0]);
		settings.theme = tempTheme;
		return false;
	} );

	$('[data-toggle="tooltip"]').tooltip();

	// Set up other stuff

	initFiles();
	initTabs();
	initChatListeners();

	// loading settings.ini
	try {
		var readFile = fs.readFileSync( `${execPath}settings/settings.ini` );
		settings = $.parseJSON( readFile );

		// Setting up config area
		$('#getOauthField').val( settings.access_token );
		$('#getChannelField').val( settings.channel );
		$('#displayName').html( settings.username );

		// Setting up theme
		try {
			fs.readFileSync( `${execPath}themes/${settings.theme}` );
			$('#botTheme').attr( 'href', `${execPath}themes/${settings.theme}` );
			$('#botThemeCurrent').html( settings.theme.split('.')[0] );
		} catch (e) {}

		// Running tabs
		startChat();
	} catch (e) {
		$('#getOauthField').val( '' );
		setupOauth();
	}
} );

function initTabs() {
	// setting up moderation area
	moderationSetup();

	// setting up the commands area
	cmdSetup();

	// setting up the points
	pointsSetup();

	// getting twitch and bttv emoticons
	getEmoticons();

	// setting up timed messages
	timedMessagesSetup();

	// setting up stats stuff
	statsSetup();

	// setting up the raffle tab
	raffleSetup();

	// setting up songs
	songsSetup();

	// set up the events part
	eventSetup();

	// set up the quotes
	quoteSetup();

	// starting the timer
	timerSetup();

	// set up mods
	apiSetup();
}

function initFiles() {
	try { fs.accessSync( `${execPath}logs` ); }
	catch (e) { fs.mkdirSync( `${execPath}logs` ); }

	try { fs.accessSync( `${execPath}txt` ); }
	catch (e) { fs.mkdirSync( `${execPath}txt` ); }

	try { fs.accessSync( `${execPath}settings` ); }
	catch (e) { fs.mkdirSync( `${execPath}settings` ); }

	// Making sure themes folder exists
	try { fs.accessSync( `${execPath}themes` ); }
	catch (e) { fs.mkdirSync( `${execPath}themes` ); }

	// Setting up the chat log
	var d = new Date();
	var dmonth = d.getMonth() + 1;
	dmonth = dmonth < 10 ? '0' + dmonth : dmonth;
	var dday = d.getDate() < 10 ? '0' + d.getDate() : d.getDate();
	var dhour = d.getHours() < 10 ? '0' + d.getHours() : d.getHours();
	var dmin = d.getMinutes() < 10 ? '0' + d.getMinutes() : d.getMinutes();
	var dsec = d.getSeconds() < 10 ? '0' + d.getSeconds() : d.getSeconds();
	var logname = `chatlog_${d.getFullYear()}-${dmonth}-${dday}_${dhour}-${dmin}-${dsec}.log`;
	logFile = `${execPath}logs/${logname}`;

	fs.writeFile( `${execPath}txt/host-session.txt`, '' );
	fs.writeFile( `${execPath}txt/follow-session.txt`, '' );
	fs.writeFile( `${execPath}txt/sub-session.txt`, '' );
}

function initChatListeners() {
	document.addEventListener('twapiRaw', function( e ) {
		// You really don't NEED to see raw messages. But you can if you want.
		// You can also manually parse the raw messages if you don't trust TWAPI.js
		// writeChat( '* ' + e.detail );
	} );
	document.addEventListener('twapiRawGroup', function( e ) {
		// You really don't NEED to see raw messages from the group server. But you can if you want.
		// You can also manually parse the raw messages from the group server if you don't trust TWAPI.js
		// writeChat( '+ ' + e.detail );
	} );
	document.addEventListener('twapiNotice', function( e ) {
		writeChat( e.detail );
	} );
	document.addEventListener('twapiJoin', function( e ) {
		writeChat( e.detail + ' has joined.' );
	} );
	document.addEventListener('twapiPart', function( e ) {
		writeChat( e.detail + ' has left the channel.' );
	} );
	document.addEventListener('twapiClear', function( e ) {
		writeChat( e.detail + ' has been cleared (aka purged/timedout).' );
	} );
	document.addEventListener('twapiHost', function( e ) {
		writeChat( e.detail + ' is hosting you.' );
	} );
	document.addEventListener('twapiFollow', function( e ) {
		writeChat( e.detail + ' has followed you.' );
	} );
	document.addEventListener('twapiSub', function( e ) {
		writeChat( e.detail + ' has just subscribed!' );
	} );
	document.addEventListener('twapiSubMonths', function( e ) {
		writeChat( e.detail.name + ' has resubbed ' + e.detail.months + ' times!' );
	} );
	document.addEventListener('twapiSubsAway', function( e ) {
		writeChat( e.detail + ' users have subbed since you have been offline.' );
	} );
	document.addEventListener('twapiRoomstate', function( e ) {
		var output = 'Roomstate options: ';
		if ( e.detail.lang ) output += ' lang:' + e.detail.lang;
		if ( e.detail.r9k ) output += ' r9k';
		if ( e.detail.slow ) output += ' slow';
		if ( e.detail.subs_only ) output += ' subs-only';
		if ( !e.detail.lang && !e.detail.r9k && !e.detail.slow && !e.detail.subs_only ) {
			output += ' none.';
		}
		writeChat( output );
	} );
	document.addEventListener('twapiMsg', function( e ) {
		var output = (e.detail.mod ? '<img src="http://chat-badges.s3.amazonaws.com/mod.png">' : '') +
			(e.detail.sub  ?'<img src="' + TWAPI.getSubBadgeUrl() + '">' : '') +
			(e.detail.turbo ? '<img src="http://chat-badges.s3.amazonaws.com/turbo.png">' : '') +
			(e.detail.streamer ? '<img src="http://chat-badges.s3.amazonaws.com/broadcaster.png">' : '') +
			'<strong style="color: ' + e.detail.color + ';">' +
			e.detail.from +
			'</strong>&nbsp;' +
			(e.detail.action ? '<span style="color: ' + e.detail.color + ';">' : ':&nbsp;&nbsp;') +
			e.detail.text +
			(e.detail.action ? '</span>' : '' );
			// e.detail.emotes is the emotes, e.g. '25:0-4,12-16/1902:6-10'
			// https://github.com/justintv/Twitch-API/blob/master/IRC.md#privmsg
		writeChat( output );
	} );
	document.addEventListener('twapiNoticeGroup', function( e ) {
		writeChat( e.detail );
	} );
	document.addEventListener('twapiWhisper', function( e ) {
		var output = (e.detail.turbo ? '<img src="http://chat-badges.s3.amazonaws.com/turbo.png">' : '') +
			'<strong style="color: ' + e.detail.color + ';">' +
			e.detail.from +
			'</strong>' +
			' &gt; ' +
			'<strong>' + e.detail.to + '</strong> : ' +
			e.detail.text;
		// e.detail.message_id & e.detail.thread_id & e.detail.user_id contain their respective ids
		// When using whispers for a bot, be sure to whitelist it: https://discuss.dev.twitch.tv/t/are-your-whispers-not-going-through-for-your-bot/5183/3
		writeChat( output );
	} );
}

function startChat() {
	TWAPI.setup(clientid, settings.access_token, function(username) {
		settings.username = username;
		$('#displayName').html( settings.username );

		getEmoticons();

		channelEnter();
	} );
}

// This is run every time a channel is entered
function channelEnter() {
	$('#getChannelField').val( settings.channel );

	getEmoticonsBTTV();

	TWAPI.runChat( settings.channel.substring(1), function() {
		setTimeout(function(){
			subBadgeUrl = TWAPI.getSubBadgeUrl();
			eventSettings.isPartnered = TWAPI.isPartner();
			$('#gameField').val( TWAPI.getGame() );
			$('#statusField').val( TWAPI.getStatus() );
			setTitle(`${TWAPI.getStatus()} &mdash; ${TWAPI.getGame()} &mdash;`);
		}, 1000);
	});
}

function updateUserlist() {
	var chatters = TWAPI.getChatters();
	if ( !chatters ) return;

	exportViewers( TWAPI.getCurrentViewCount() ); //stats

	$('#viewercount').html( `
		<span class="glyphicon glyphicon-user text-info"></span>
		&nbsp;&nbsp;&nbsp;${ TWAPI.getCurrentViewCount().toLocaleString() }
		<br>
		<span class="glyphicon glyphicon-heart text-danger"></span>
		&nbsp;&nbsp;&nbsp;${ TWAPI.getFollowerCount().toLocaleString() }` );

	fs.writeFile( `${execPath}txt/follower-total-count.txt`, `${followerCount.toLocaleString()}` );
	fs.writeFile( `${execPath}txt/viewer-current-count.txt`, `${viewerCount.toLocaleString()}` );

	currentUsers = []; // {username: string, role: string} for points

	var output = '';

	var staffLen = chatters.staff.length;
	if (staffLen > 0) {
		output += `<p> <b style='color: #6d35ac;'>STAFF (${staffLen})</b> <br> `;
		for (var i = 0; i < staffLen; i++) {
			var tempuser = chatters.staff[i];
			output += `${tempuser} <br> `;
			currentUsers.push({"username": tempuser, "role": "staff"});
		}
		output += '</p> ';
	}

	var modLen = chatters.moderators.length;
	if (modLen > 0) {
		output += `<p> <b style='color: #34ae0a;'>MODS (${modLen})</b> <br> `;
		for (var i = 0; i < modLen; i++) {
			var tempuser = chatters.moderators[i];
			output += `${tempuser} <br> `;
			currentUsers.push({"username": tempuser, "role": "moderator"});
		}
		output += '</p> ';
	}

	var adminLen = chatters.admins.length;
	if (adminLen > 0) {
		output += `<p> <b style='color: #faaf19;'>ADMINS (${adminLen})</b> <br> `;
		for (var i = 0; i < adminLen; i++) {
			var tempuser = chatters.admins[i];
			output += `${tempuser} <br> `;
			currentUsers.push({"username": tempuser, "role": "admin"});
		}
		output += '</p> ';
	}

	var globalLen = chatters.global_mods.length;
	if (globalLen > 0) {
		output += `<p> <b style='color: #1a7026;'>GLOBAL MODS (${globalLen})</b> <br> `;
		for (var i = 0; i < globalLen; i++) {
			var tempuser = chatters.global_mods[i];
			output += `${tempuser} <br> `;
			currentUsers.push({"username": tempuser, "role": "globalmod"});
		}
		output += '</p> ';
	}

	var viewLen = chatters.viewers.length;
	if (viewLen > 0) {
		output += `<p> <b style='color: #2e7db2;'>VIEWERS (${viewLen})</b> <br> `;
		for (var i = 0; i < viewLen; i++) {
			var tempuser = chatters.viewers[i];
			output += `${tempuser} <br> `;
			currentUsers.push({"username": tempuser, "role": "viewer"});
		}
		output += '</p> ';
	}

	$('#userlist').html(output);
}

function getEmoticons() {
	$.getJSON(
		'https://api.twitch.tv/kraken/chat/emoticons',
		{
			"client_id" : clientid,
			"api_version" : 3
		},
		function( response ) {
			if ( 'emoticons' in response ) {
				for (var i in response.emoticons) {
					emoticons[response.emoticons[i].regex] = response.emoticons[i].images[0].url;
				}
			}
			else {
				setTimeout( function() { getEmoticons(); }, 5*1000 );
			}
		}
	);

}

function getEmoticonsBTTV() {
	$.getJSON(
		`https://api.betterttv.net/2/channels/${settings.channel.substring(1)}`,
		{},
		function ( response ) {
			if ( 'emotes' in response ) {
				for (var i in response.emotes) {
					emoticons[response.emotes[i].code] = `https://cdn.betterttv.net/emote/${response.emotes[i].id}/1x`;
				}
			}
		}
	);

	$.getJSON(
		'https://api.betterttv.net/emotes',
		{},
		function ( response ) {
			if ( "emotes" in response ) {
				for (var i in response.emotes) {
					emoticons[response.emotes[i].regex] = `https:${response.emotes[i].url}`;
				}
			}
		}
	);
}

function writeEmoticons( message ) {
	var output = '';
	var text = message.split(' ');

	var arrayWords = ['every',
		'join',
		'concat',
		'filter',
		'map',
		'pop',
		'push',
		'reduce',
		'reverse',
		'shift',
		'some',
		'slice',
		'sort',
		'unshift',
		'length',
		'prototype',
		'constructor',
		'find'
	];

	// for each word, check if it's an emoticon and if it is, output the url instead of the text
	for( var i = 0; i < text.length; i++ ) {
		var word = text[i];
		// Check arrayWords...
		var found = false;
		for( var x = 0; x < arrayWords.length; x++ ) {
			if ( arrayWords[x] == word ) {
				found = true;
				break;
			}
		}

		if (!found && emoticons[word] ) {
			output += `<abbr title="${word}"><img src="${emoticons[word]}"></abbr> `;
		}
		else {
			output += `${word} `;
		}
	}

	return output;
}

function log( message ) {
	var out = document.getElementById( 'console' );

	// scrollHeight = element's total height including overflow
	// clientHeight = element's height including padding excluding horizontal scroll bar
	// scrollTop = distance from an element's top to its topmost visible content, it's 0 if there's no scrolling needed
	// allow 1px inaccuracy by adding 1

	// if it's scrolled to the bottom within 20px before a chat message shows up, set isScrolledToBottom to true
	var isScrolledToBottom = out.scrollHeight - out.clientHeight <= out.scrollTop + 20;

	// add message
	// var start = $.now();
	$('#console').append( `${writeEmoticons(message)} <br>` );
	// console.log(`${parseInt($.now())-parseInt(start)}ms : "${message}"`);

	// if it was scrolled to the bottom before the message was appended, scroll to the bottom
	if( isScrolledToBottom )
		out.scrollTop = out.scrollHeight - out.clientHeight;

	// remove html tags before writing to the log
	var wrapped = $(`<div>${message}</div>`);
	message = wrapped.text();

	// write to log
	fs.appendFile( logFile, `${message}\r\n`, function ( err ) {
		if ( err ) $('#console').append(`* Error writing to log <br>`);
	} );
}

function chat() {
	// get the chat input box value
	var text = $('#chatText').val();

	// output it to the console
	log( `${getTimeStamp()} <b>&gt;</b> ${text.replace(/</g,'&lt;').replace(/>/g,'&gt;')}` );

	// check if it was a command...
	if ( text.substring(0, 1) === cmdSettings.symbol ) {
		parseCommand( text, settings.username, true, true);
	}
	else {
		// send the data to the irc server
		TWAPI.sendChat( text );
	}

	// clear the chat input box
	$('#chatText').val('');
}

function getTimeStamp() {
	var dt = new Date();
	var hrs = dt.getHours();
	var mins = dt.getMinutes();

	if ( hrs < 10 ) hrs = '0' + hrs;
	if ( mins < 10 ) mins = '0' + mins;

	return `[${hrs}:${mins}]`;
}

function save() {
	// saving settings.ini
	fs.writeFile( `${execPath}settings/settings.ini`, JSON.stringify( settings ) );

	// saving modSettings.ini
	fs.writeFile( `${execPath}settings/modSettings.ini`, JSON.stringify( modSettings ) );

	// saving timedMessages.ini
	fs.writeFile( `${execPath}settings/timedMessages.ini`, JSON.stringify( timedMessages ) );

	// saving cmdSettings.ini
	fs.writeFile( `${execPath}settings/cmdSettings.ini`, JSON.stringify( cmdSettings ) );

	// saving raffleSettings.ini
	fs.writeFile( `${execPath}settings/raffleSettings.ini`, JSON.stringify( raffleSettings ) );

	// saving eventSettings.ini
	fs.writeFile( `${execPath}settings/eventSettings.ini`, JSON.stringify( eventSettings ) );

	// saving songSettings.ini
	fs.writeFile( `${execPath}settings/songSettings.ini`, JSON.stringify( songSettings ) );

	// saving defaultCommands.ini
	fs.writeFile( `${execPath}settings/defaultCommands.ini`, JSON.stringify( defaultCommands ) );

	// saving pointsSettings.ini
	if ( pointsSettings.users ) {
		var tempUserArray = [];
		var keyList = Object.keys( pointsSettings.users );
		for (var i = 0; i < keyList.length; i++) {
			var tempName = keyList[i];
			tempUserArray.push( {
				username: tempName,
				totalPoints: pointsSettings.users[tempName].totalPoints,
				currentPoints: pointsSettings.users[tempName].currentPoints
			} );
		}
		var tempPointsSettings = {
			enabled: pointsSettings.enabled,
			unit: pointsSettings.unit,
			regularPoints: pointsSettings.regularPoints,
			pointsPerUpdate: pointsSettings.pointsPerUpdate,
			minutesPerUpdate: pointsSettings.minutesPerUpdate,
			ranks: pointsSettings.ranks,
			users: tempUserArray
		};

		fs.writeFile( `${execPath}settings/pointsSettings.ini`, JSON.stringify( tempPointsSettings ) );
	}

	console.log( 'Settings saved' );
}

function setupOauth() {
	if ( !oauthsetup ) {
		var express = require( 'express' );
		var app = express();
		app.use( express.static( 'public' ) );
		app.get( '/oauth', function(req, res) {
			$('#getOauthModal').modal( 'hide' );
			$('#oauthFrame').attr('src', '');
			if ( req.query.token.length > 20 ) {
				settings.access_token = req.query.token;
				$('#getOauthField').val( req.query.token );
				startChat();
			}
		} );
		app.listen( 3000 );

		oauthsetup = true;
	}
	doOauth();
	return false;
}

function doOauth() {
	$('#oauthFrame').attr('src', `https://api.twitch.tv/kraken/oauth2/authorize?
	response_type=token&
	client_id=3y2ofy4qcsvnaybw9ogdzwmwfode8y0&
	redirect_uri=http://localhost:3000/oauth.html&
	scope=channel_editor+chat_login&
	force_verify=true`);

	$('#getOauthModal').modal('show');
}


// https://github.com/nwjs/nw.js/wiki/Shell
function openLink(url) {
	nw.Shell.openExternal(url);
}

function setTitle(title) {
	var version = nw.App.manifest.version;
	$('title').html(`${title} KoalaBot ${ version }`);
}
